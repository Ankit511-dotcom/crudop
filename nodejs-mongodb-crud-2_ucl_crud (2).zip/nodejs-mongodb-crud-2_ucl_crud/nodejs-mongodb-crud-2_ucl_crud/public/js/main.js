// THIS IS FRONT END JAVASCRIPT


const url = window.location.href;
// const edit = document.getElementById('edit');
const editButton = document.querySelectorAll('.editBtn');
const form = document.getElementById('form');

// THIS IS FOR INPUT FEILD AND IT'S REPLACABLE
const p_id = document.getElementById('p_id'),
    p_name = document.getElementById('p_name'),
    c_id = document.getElementById('c_id');
    c_name = document.getElementById('c_id');










// THIS IS FOR TABLE NOT REPLACEABLE
const p_id = document.getElementById('p_id'),
    p_name = document.getElementById('p_name'),
    c_id = document.getElementById('c_id');
    c_name = document.getElementById('c_id');





// console.log(allAttr(name,name.id));


const names = [p_id,p_name,c_id,c_name];


// console.log(names);


// const team = [teamName, teamPlayers, teamCoach];






// console.log(form.attributes.action.value);
let edit_url = url + "edit/";

valueChange();

function valueChange() {
    editButton.forEach(edit => {
        edit.addEventListener('click', e => {
            // e.preventDefault();

            console.log(teamName.textContent);
            p_id.value = p_id.textContent;
            p_name.value = p_name.textContent;
            c_id.value = c_id.textContent;
            c_name.value = c_name.textContent;
        





            // console.log(e.target.parentNode.parentNode);
            console.log(e.target.parentNode.parentNode);
            // location.reload();
        });
    });
}






// GETTING VALUE 
const setValue=(props)=>{
    this.props = props;
    props.forEach(val => {
        this.props = val.attributes.value.value;
    });
    return this.props;
}


