# CRUD

**Recomanded Packages**

 - body-parser
 - connect-flash
 - express
 - express-messages
 - express-session
 - express-validator
 - mongoose
 - pug